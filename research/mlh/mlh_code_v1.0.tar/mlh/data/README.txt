This folder will contain dataset files which you should download
separately:

- LabelMe_gist.mat is the 22K LabelMe dataset available from
http://cs.nyu.edu/~fergus/research/tfw_cvpr08_code.zip, (within archive),
or http://www.cs.toronto.edu/~norouzi/research/mlh/data/LabelMe_gist.mat,
courtesy of Rob Fergus. Store the file under data/ folder.

- *.mtx files for 5 small datasets (MNIST, LabelMe, Peekaboom,
Photo-Tourism, Nursery) can be downloaded from
http://www.eecs.berkeley.edu/~kulis/data/, courtesy of Brian
Kulis. Store the files under data/kulis/ directory.
